// Servidor para la PC (el "backend en Node.js" de las capturas). Sin nada que
// instalar: solo Node 18 o más nuevo.
//   node servidor.mjs            https en el puerto 3000 (lo que pide el Quest)
//   node servidor.mjs --http     http, para usar con el cable: adb reverse tcp:3000 tcp:3000
// Hace tres cosas:
//   - sirve la página (index.html, al lado de este archivo)
//   - recibe el POST de la tecla en /api y, si le decís cómo, prende o apaga un
//     enchufe inteligente: variables PRENDER y APAGAR con la dirección de cada orden
//     (Shelly:  PRENDER=http://192.168.0.50/relay/0?turn=on)
//     (Tasmota: PRENDER="http://192.168.0.50/cm?cmnd=Power%20On")
//   - lleva la partida de 4 en línea entre el visor y la PC (/api/mesa)
// El Quest solo abre la realidad mixta desde https: la primera vez el servidor
// fabrica un certificado propio (cert.pem y key.pem) y el navegador avisa que la
// conexión "no es privada"; se acepta una vez (Avanzado → Continuar).

import http from 'node:http'
import https from 'node:https'
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { networkInterfaces } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import crypto from 'node:crypto'

const aqui = dirname(fileURLToPath(import.meta.url))
const { nuevo, jugar } = await import(existsSync(join(aqui, 'cuatro.js')) ? './cuatro.js' : './src/cuatro.js')
const PUERTO = Number(process.env.PUERTO || 3000)
const conHttps = !process.argv.includes('--http')

// la página armada: en el repo está en dist/; en el paquete para bajar, al lado de este archivo
const pagina = [join(aqui, '../dist/xr/local/index.html'), join(aqui, 'index.html')].find(existsSync)
if (!pagina) { console.error('Falta index.html al lado de servidor.mjs'); process.exit(1) }

// ---------- la tecla ----------

const tecla = { estado: 'apagado', veces: 0, ultima: null }
async function ordenar(estado) {
  const url = estado === 'prendido' ? process.env.PRENDER : process.env.APAGAR
  if (!url) return 'sin configurar'
  try { const r = await fetch(url, { signal: AbortSignal.timeout(3000) }); return r.ok ? 'ok' : `error ${r.status}` } catch (e) { return 'no contesta' }
}

// ---------- la mesa ----------

const sala = { partida: nuevo(), version: 0, jugadores: {} } // jugadores: color → { id, visto }
const VENCE = 15000
function limpiarSala() {
  for (const [c, j] of Object.entries(sala.jugadores)) if (Date.now() - j.visto > VENCE) delete sala.jugadores[c]
}
const colorDe = id => Object.keys(sala.jugadores).find(c => sala.jugadores[c].id === id)
const vista = () => ({ partida: sala.partida, version: sala.version, jugadores: Object.keys(sala.jugadores) })

// ---------- rutas ----------

async function cuerpo(req) {
  let t = ''
  for await (const parte of req) { t += parte; if (t.length > 1e5) break }
  try { return JSON.parse(t || '{}') } catch { return {} }
}
function json(res, codigo, datos) {
  res.writeHead(codigo, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
  res.end(JSON.stringify(datos))
}

async function atender(req, res) {
  const url = new URL(req.url, 'http://x')
  const ruta = url.pathname.replace(/\/+$/, '') || '/'
  try {
    if (req.method === 'GET' && (ruta === '/' || ruta === '/index.html')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' })
      return res.end(readFileSync(pagina))
    }
    if (ruta === '/api/hola') return json(res, 200, { servidor: 'arrancalo-xr' })

    if (ruta === '/api' && req.method === 'POST') {
      const b = await cuerpo(req)
      tecla.estado = b.estado === 'prendido' ? 'prendido' : 'apagado'
      tecla.veces++
      tecla.ultima = new Date().toISOString()
      const dispositivo = await ordenar(tecla.estado)
      console.log(`${new Date().toLocaleTimeString()}  tecla: ${tecla.estado.toUpperCase()}  (enchufe: ${dispositivo})`)
      return json(res, 200, { ok: true, ...tecla, dispositivo })
    }
    if (ruta === '/api' && req.method === 'GET') return json(res, 200, tecla)

    if (ruta.startsWith('/api/mesa')) {
      limpiarSala()
      const b = req.method === 'POST' ? await cuerpo(req) : { id: url.searchParams.get('id') }
      const yo = colorDe(b.id)
      if (yo) sala.jugadores[yo].visto = Date.now()
      if (ruta === '/api/mesa' && req.method === 'GET') return json(res, 200, { ...vista(), color: yo || null })
      if (ruta === '/api/mesa/entrar' && req.method === 'POST') {
        let color = yo || ['rojo', 'amarillo'].find(c => !sala.jugadores[c])
        if (!color) return json(res, 200, { ...vista(), color: null })
        if (!yo) {
          sala.jugadores[color] = { id: b.id, visto: Date.now() }
          console.log(`mesa: entró alguien con las ${color === 'rojo' ? 'rojas' : 'amarillas'}`)
        }
        return json(res, 200, { ...vista(), color })
      }
      if (ruta === '/api/mesa/jugar' && req.method === 'POST') {
        const fila = yo ? jugar(sala.partida, Number(b.col), yo) : -1
        if (fila >= 0) sala.version++
        return json(res, 200, { ok: fila >= 0, ...vista(), color: yo || null })
      }
      if (ruta === '/api/mesa/nueva' && req.method === 'POST') {
        if (yo) { sala.partida = nuevo(); sala.version++ }
        return json(res, 200, { ok: !!yo, ...vista(), color: yo || null })
      }
      if (ruta === '/api/mesa/salir' && req.method === 'POST') {
        if (yo) delete sala.jugadores[yo]
        return json(res, 200, { ok: true })
      }
    }
    json(res, 404, { error: 'no existe' })
  } catch (e) {
    console.error(e)
    json(res, 500, { error: 'algo falló' })
  }
}

// ---------- certificado propio (sin openssl) ----------

const ips = Object.values(networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address)

function certificadoPropio() {
  const dir = process.env.CERTS || aqui // dónde guardarlo (las pruebas usan otra carpeta)
  const certPath = join(dir, 'cert.pem'), keyPath = join(dir, 'key.pem')
  if (existsSync(certPath) && existsSync(keyPath)) return { cert: readFileSync(certPath), key: readFileSync(keyPath) }
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 })
  // DER a mano: lo justo para un certificado X.509 v3 autofirmado
  const largo = n => (n < 128 ? [n] : n < 256 ? [0x81, n] : [0x82, n >> 8, n & 255])
  const tlv = (tag, ...partes) => { const c = Buffer.concat(partes.map(p => (Buffer.isBuffer(p) ? p : Buffer.from(p)))); return Buffer.concat([Buffer.from([tag, ...largo(c.length)]), c]) }
  const seq = (...p) => tlv(0x30, ...p)
  const oid = s => {
    const n = s.split('.').map(Number), b = [n[0] * 40 + n[1]]
    for (const x of n.slice(2)) { const t = []; let v = x; do { t.unshift(v & 127); v >>= 7 } while (v); for (let k = 0; k < t.length - 1; k++) t[k] |= 128; b.push(...t) }
    return tlv(0x06, b)
  }
  const fecha = d => tlv(0x17, Buffer.from(d.toISOString().replace(/[-:T]/g, '').slice(2, 14) + 'Z'))
  const nombre = seq(tlv(0x31, seq(oid('2.5.4.3'), tlv(0x0c, Buffer.from('arrancalo-xr')))))
  const algoritmo = seq(oid('1.2.840.113549.1.1.11'), tlv(0x05))
  const serie = crypto.randomBytes(8); serie[0] &= 0x7f
  const hoy = new Date(), vence = new Date(Date.now() + 5 * 365 * 864e5)
  const alternativos = seq(...ips.map(ip => tlv(0x87, ip.split('.').map(Number))), tlv(0x87, [127, 0, 0, 1]), tlv(0x82, Buffer.from('localhost')))
  const tbs = seq(
    tlv(0xa0, tlv(0x02, [2])), tlv(0x02, serie), algoritmo, nombre, seq(fecha(hoy), fecha(vence)), nombre,
    publicKey.export({ type: 'spki', format: 'der' }),
    tlv(0xa3, seq(seq(oid('2.5.29.17'), tlv(0x04, alternativos)))),
  )
  const firma = crypto.sign('sha256', tbs, privateKey)
  const der = seq(tbs, algoritmo, tlv(0x03, Buffer.concat([Buffer.from([0]), firma])))
  const cert = `-----BEGIN CERTIFICATE-----\n${der.toString('base64').match(/.{1,64}/g).join('\n')}\n-----END CERTIFICATE-----\n`
  const key = privateKey.export({ type: 'pkcs8', format: 'pem' })
  writeFileSync(certPath, cert); writeFileSync(keyPath, key)
  return { cert, key }
}

// ---------- arrancar ----------

const servidor = conHttps ? https.createServer(certificadoPropio(), atender) : http.createServer(atender)
servidor.listen(PUERTO, () => {
  const esquema = conHttps ? 'https' : 'http'
  console.log('\nServidor andando. Abrí una de estas direcciones:')
  if (conHttps) for (const ip of ips) console.log(`  En el Quest:  ${esquema}://${ip}:${PUERTO}`)
  else console.log(`  En el Quest (con el cable y adb reverse):  http://localhost:${PUERTO}`)
  console.log(`  En esta PC:   ${esquema}://localhost:${PUERTO}`)
  if (conHttps) console.log('  La primera vez el navegador avisa que la conexión no es privada: Avanzado → Continuar.')
  console.log(`  Enchufe: ${process.env.PRENDER ? 'configurado' : 'sin configurar (la tecla solo avisa acá)'}`)
  console.log('Para cortar: Ctrl+C\n')
})
