// 4 en línea, sin pantalla: el tablero, las jugadas, quién ganó y la compu.
// Lo usan la página (mesa.js) y el servidor (servidor.mjs), que valida las jugadas
// de una partida entre el visor y la PC.

export const COLS = 7, FILAS = 6

// tablero[col][fila], fila 0 abajo; null, 'rojo' o 'amarillo'
export const nuevo = () => ({ tablero: Array.from({ length: COLS }, () => Array(FILAS).fill(null)), turno: 'rojo', ganador: null, linea: null, jugadas: 0 })

export const otro = c => (c === 'rojo' ? 'amarillo' : 'rojo')
export const libre = (p, col) => col >= 0 && col < COLS && p.tablero[col][FILAS - 1] === null && !p.ganador

// Juega en la columna; devuelve la fila donde cayó o -1 si no se puede.
export function jugar(p, col, color = p.turno) {
  if (color !== p.turno || !libre(p, col)) return -1
  const fila = p.tablero[col].indexOf(null)
  p.tablero[col][fila] = color
  p.jugadas++
  const linea = lineaDesde(p.tablero, col, fila)
  if (linea) { p.ganador = color; p.linea = linea } else if (p.jugadas === COLS * FILAS) p.ganador = 'empate'
  p.turno = otro(color)
  return fila
}

const DIRS = [[1, 0], [0, 1], [1, 1], [1, -1]]
function lineaDesde(t, col, fila) {
  const c = t[col][fila]
  for (const [dx, dy] of DIRS) {
    const l = [[col, fila]]
    for (const s of [1, -1]) for (let k = 1; k < 4; k++) {
      const x = col + dx * k * s, y = fila + dy * k * s
      if (x < 0 || x >= COLS || y < 0 || y >= FILAS || t[x][y] !== c) break
      l.push([x, y])
    }
    if (l.length >= 4) return l
  }
  return null
}

// ---------- la compu ----------

// Puntaje de una ventana de 4 casillas, desde el punto de vista de 'yo'.
function ventana(v, yo) {
  const mias = v.filter(x => x === yo).length, suyas = v.filter(x => x === otro(yo)).length, vacias = 4 - mias - suyas
  if (mias && suyas) return 0
  if (mias === 3 && vacias === 1) return 50
  if (mias === 2 && vacias === 2) return 8
  if (suyas === 3 && vacias === 1) return -60
  if (suyas === 2 && vacias === 2) return -6
  return 0
}
function evaluar(t, yo) {
  let s = 0
  for (let y = 0; y < FILAS; y++) if (t[3][y] === yo) s += 4 // el medio vale más
  for (let x = 0; x < COLS; x++) for (let y = 0; y < FILAS; y++) for (const [dx, dy] of DIRS) {
    const x3 = x + dx * 3, y3 = y + dy * 3
    if (x3 < 0 || x3 >= COLS || y3 < 0 || y3 >= FILAS) continue
    s += ventana([0, 1, 2, 3].map(k => t[x + dx * k][y + dy * k]), yo)
  }
  return s
}
const copiar = p => ({ ...p, tablero: p.tablero.map(c => [...c]) })
const ORDEN = [3, 2, 4, 1, 5, 0, 6]

function minimax(p, prof, a, b, yo) {
  if (p.ganador === yo) return 100000 + prof
  if (p.ganador === 'empate') return 0
  if (p.ganador) return -100000 - prof
  if (prof === 0) return evaluar(p.tablero, yo)
  const maximiza = p.turno === yo
  let mejor = maximiza ? -Infinity : Infinity
  for (const col of ORDEN) {
    if (!libre(p, col)) continue
    const q = copiar(p)
    jugar(q, col)
    const v = minimax(q, prof - 1, a, b, yo)
    if (maximiza) { mejor = Math.max(mejor, v); a = Math.max(a, v) } else { mejor = Math.min(mejor, v); b = Math.min(b, v) }
    if (b <= a) break
  }
  return mejor
}

// La mejor columna para quien tiene el turno. prof 5 juega bien sin ser imbatible.
export function jugadaCompu(p, prof = 5) {
  let mejor = -1, valor = -Infinity
  for (const col of ORDEN) {
    if (!libre(p, col)) continue
    const q = copiar(p)
    jugar(q, col)
    const v = minimax(q, prof - 1, -Infinity, Infinity, p.turno)
    if (v > valor) { valor = v; mejor = col }
  }
  return mejor
}
